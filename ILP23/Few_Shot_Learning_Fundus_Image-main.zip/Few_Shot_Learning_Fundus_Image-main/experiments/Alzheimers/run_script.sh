yap -l run.pl > output.txt
