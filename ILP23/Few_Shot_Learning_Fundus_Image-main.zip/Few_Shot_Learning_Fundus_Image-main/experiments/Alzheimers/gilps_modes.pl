
:-modeh(1, target(+image)).
:-modeb(1, crae(+image,-group)).
:-modeb(1, crve(+image,-group)).
:-modeb(1, avr(+image,-group)).
:-modeb(1, bstda(+image,-group)).
:-modeb(1, bstdv(+image,-group)).
:-modeb(1, fda(+image,-group)).
:-modeb(1, fdv(+image,-group)).
:-modeb(1, torta(+image,-group)).
:-modeb(1, tortv(+image,-group)).

:-modeb(*, lteq(+group,#float)).
:-modeb(*, gteq(+group,#float)).



